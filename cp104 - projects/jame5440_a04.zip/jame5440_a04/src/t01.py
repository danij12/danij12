"""
-------------------------------------------------------
Lab/Assignment  Testing
-------------------------------------------------------
Author:  Daniel James
ID:      210265440
Email:   jame5440@mylaurier.ca
Version: 2021-10-08
-------------------------------------------------------
"""
#Imports 
from functions import day_of_week
num = int(input('Enter a number: '))
day = day_of_week(num)
print(f'day_week_week({num}) -> "{day}"')