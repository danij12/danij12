"""
-------------------------------------------------------
Lab/Assignment  Testing
-------------------------------------------------------
Author:  Daniel James
ID:      210265440
Email:   jame5440@mylaurier.ca
Version: 2021-10-08
-------------------------------------------------------
"""
#1, 3, 5, 7, 9
from functions import hi_lo_game
#Variables 

count = hi_lo_game(50)
print(f'You made {count} guess')