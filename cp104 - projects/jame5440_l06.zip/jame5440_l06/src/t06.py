"""
-------------------------------------------------------
Lab/Assignment  Testing
-------------------------------------------------------
Author:  Daniel James
ID:      210265440
Email:   jame5440@mylaurier.ca
Version: 2021-10-08
-------------------------------------------------------
"""
from functions import draw_triangle
height = int(input('Enter height in characters: '))
char = input('Enter the draw character: ')
draw_triangle(height,char)